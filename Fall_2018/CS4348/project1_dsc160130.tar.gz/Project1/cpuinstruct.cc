#include "cpuinstruct.h"
CPU::CPU() {
  this->PC = 0;
  this->SP = 1999;
  this->IR = 0;
}

void CPU::loadValue(int AC) {
  this->AC = AC;
}

void CPU::loadAddr(int addr) {
  
}
