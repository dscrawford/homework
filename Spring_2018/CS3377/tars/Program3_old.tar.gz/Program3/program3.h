//Made by Daniel Crawford(dsc160130@utdallas.edu) on 2/16/2018
//Section 3377.501

#include <iostream>
#include <stdlib.h>
std::string getgawkcommand(std::string);
void getResults(int&, int&, std::string);

//Path to gawk bin
extern std::string PATH;
