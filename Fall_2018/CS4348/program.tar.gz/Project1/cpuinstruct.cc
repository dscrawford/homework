#include "cpuinstruct.h"


CPU::CPU(int* rampipe, int* cpupipe) {
  //Initialize variables and arrays;
  userstck = new int[SIZE];
  systemstck = new int[SIZE];
  this->PC = this->SIZE - 1;
  this->SP = this->SIZE - 1;
  this->AC = 0;
  this->interruptState=false;

  this->rampipe = rampipe;
  this->cpupipe = cpupipe;
  //Close unused pipes
  close(rampipe[1]);
  close(cpupipe[0]);
}

void CPU::runProgram() {
  //Instruction and instruction count
  int instr, instrc;
  //Read instruction count
  read(rampipe[0], &instrc, sizeof(int));

  //Get all instructions and data from file.
  for (PC = 0; PC <= instrc; ++PC) {
    std::cout << "PC: " << PC << std::endl;
    //Read next instruction
    read(rampipe[0], &instr, sizeof(int));
    std::cout << "Instruction: " << instr << std::endl;
    IR = instr;

    //Sorry this is a little awkward to read
    //Following cases require communication with RAM
    int input = 0, type = 0;
    switch(IR) {
    case 1:     //Of type none but needs to read next line of input
    case 9:
      type = 3;
      //Need to write types two times because it needs to account for both
      //instruction and the input
      write(cpupipe[1], &type, sizeof(int));
      write(cpupipe[1], &type, sizeof(int));
      read(rampipe[0], &input, sizeof(int));
      break;
      
    case 2:      //Of type read
    case 3:
    case 4:
    case 5:
      type = 0;
      write(cpupipe[1], &type, sizeof(int));
      read(rampipe[0], &input, sizeof(int));
      break;
      
    case 6:     //Of type store
      type = 1;
      write(cpupipe[1], &type, sizeof(int));
      break;
      
    case 20:    //Of type jump
    case 21:
    case 22:
    case 23:
    case 24:
      type = 2;
      write(cpupipe[1], &type, sizeof(int));
      break;
      
    case 50:    //Of type exit
      type = 50;
      write(cpupipe[1], &type, sizeof(int));
      break;
      
    default:    //Of type none and no input needed
      type = 3;
      write(cpupipe[1], &type, sizeof(int));
      break;
    }
    //Run instruction
    runInstruct(IR, input);
  }
}

//Takes input incase needed for instruction
void CPU::runInstruct(int IR, int input) {
  switch (IR) {
  case 1:
    loadValue(input);
    break;
  case 2:
    loadAddr(input);
    break;
  case 3:
    loadIndaddr(input);
    break;
  case 4:
    loadIdxXaddr(input);
    break;
  case 5:
    loadIdxYaddr(input);
    break;
  case 6:
    loadSpX(input);
    break;
  case 7:
    storeAddr(input);
    break;
  case 8:
    get();
    break;
  case 9:
    putPort(input);
    break;
  case 10:
    addX();
    break;
  case 11:
    addY();
    break;
  case 12:
    subX();
    break;
  case 13:
    subY();
    break;
  case 14:
    copyToX();
    break;
  case 15:
    copyFromX();
    break;
  case 16:
    copyToY();
    break;
  case 17:
    copyFromY();
    break;
  case 18:
    copyToSP();
    break;
  case 19:
    copyFromSP();
    break;
  case 20:
    JumpAddr(input);
    break;
  case 21:
    JumpIfEqual(input);
    break;
  case 22:
    JumpIfNotEqual(input);
    break;
  case 23:
    Call(input);
    break;
  case 24:
    Ret();
    break;
  case 25:
    IncX();
    break;
  case 26:
    DecX();
    break;
  case 27:
    Push();
    break;
  case 28:
    Pop();
    break;
  case 29:
    break;
  case 30:
    break;
  case 50:
    End();
    break;
  }}


void CPU::loadValue(int input) {
  //Store value
  this->AC = input;
}

void CPU::loadAddr(int input) {
  //Indicate to memory that cpu wants something
  write(cpupipe[1], &input, sizeof(int));

  //read value found from memory
  int value;
  read(rampipe[0], &value, sizeof(int));

  loadValue(value);
}

void CPU::loadIndaddr(int input) {
  //Indicate to memory that cpu wants something
  write(cpupipe[1], &input, sizeof(int));

  //Read the value of address from input
  int value;
  read(rampipe[0], &value, sizeof(int));

  //Read the value of the address at the address
  loadValue(value);
}

void CPU::loadIdxXaddr(int input) {
  //Indicate to memory that cpu wants something at address + X
  input += this->X;
  write(cpupipe[1], &input, sizeof(int));

  //read value found from memory + value of X register
  int value;
  read(rampipe[0], &value, sizeof(int));

  loadValue(value);
}

void CPU::loadIdxYaddr(int input) {
  //Indicate to memory that cpu wants something at address + y
  input += this->Y;
  write(cpupipe[1], &input, sizeof(int));
  
  //read value found from memory + value of Y register
  int value;
  read(rampipe[0], &value, sizeof(int));

  loadValue(value);
}

void CPU::loadSpX(int input) {
  this->AC = userstck[this->SP + X];
}


void CPU::storeAddr(int input) {
  //send address
  write(cpupipe[1], &input, sizeof(int));
  //send value in AC now to RAM
  write(cpupipe[1], &(this->AC), sizeof(int));
}

void CPU::get() {
  //Generate random number between 1 and 100
  std::mt19937 rng;
  rng.seed(std::random_device()());
  std::uniform_int_distribution<std::mt19937::result_type> dist(1,100);
  this->AC = dist(rng);
}

void CPU::putPort(int input) {
  //To pring integer to screen
  if (input == 1) {
    std::cout << this->AC << std::endl;
  }
  //print char to screen
  else if (input == 2) {
    std::cout << (char)this->AC <<std::flush;
  }
  else {
    std::cerr << "ERROR: Invlad port" << std::endl;
  }
}

void CPU::addX() {
  //Subtract X from AC
  this->AC += this->X;
}

void CPU::addY() {
  //Subtract Y from AC
  this->AC += this->Y;
}

void CPU::subX() {
  //Subtract X from AC
  this->AC -= this->X;
}

void CPU::subY() {
  //Subtract Y from AC
  this->AC -= this->Y;
}

void CPU::copyToX() {
  //Give X the value in AC
  this->X = this->AC;
}

void CPU::copyFromX() {
  //Give AC the value in X
  this->AC = this->X;
}

void CPU::copyToY() {
  //Give Y the value in AC
  this->Y = this->AC;
}

void CPU::copyFromY() {
  //Give AC the value in Y
  this->AC = this->Y;
}


void CPU::copyToSP() {
  //Give SP the value in AC
  this->SP = this->AC;
}

void CPU::copyFromSP() {
  //Give AC the value in SP
  this->AC = this->SP;
}

void CPU::JumpAddr(int input) {
  write(cpupipe[1], &input, sizeof(int));
  this->PC = input;
}

void CPU::JumpIfEqual(int input) {
  if (this->AC == 0)
    JumpAddr(input);
}

void CPU::JumpIfNotEqual(int input) {
  if (this->AC != 0)
      JumpAddr(input);
}

void CPU::Call(int input) {
  addToStack(PC + 1 + 1); // Current PC + Next Instruction + Input from address
  JumpAddr(input);
}

void CPU::Ret() {
  //Jump back to instruction after call
  int PC = popStack();
  JumpAddr(PC);
}

void CPU::IncX() {
  this->X++;
}

void CPU::DecX() {
  this->X--;
}

void CPU::Push() {
  addToStack(this->AC);
}

void CPU::Pop() {
  this->AC = popStack();
}

void CPU::Int() {
}

void CPU::IRet() {
}

void CPU::End() {
  //end process
  _exit(0);
}


void CPU::addToStack(int value) {
  if (this->SP >= 0) {
    this->userstck[SP] = value;
    this->SP--;
  }
  else {
    std::cerr << "ERROR: Stack is full, cannot add(Current instruction:)"
	      << IR << std::endl;
  }
  std::cout << "STACK ADDING " << systemstck[SP] << std::endl;
}

int CPU::popStack() {
  int ret;
  if (SP < SIZE - 1) {
    ret = systemstck[SP];
    SP++;
  }
  else {
    std::cerr << "ERROR: Stack is empty, cannot pop(Current instruction:)"
	      << IR << std::endl;
    ret = -1;
  }
  std::cout << "STACK RETURING " << ret << std::endl;
  return ret;
}

CPU::~CPU() {
  delete[] systemstck;
  delete[] userstck;
}
