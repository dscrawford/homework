#!/bin/bash
kill -s SIGINT `cat cs3377dirmond.pid`
