//Made by Daniel Crawford(Email: dsc160130@utdallas.edu) on 1/20/2018
//cs 3377.501
#include <iostream>

void func1() { //Sends a message to stderr
  std::cerr << "Inside func1() as stderr" << std::endl;
}
