/* Made by Daniel Crawford on 10/18/2018
 * Email: dsc160130@utdallas.edu 
 */
#include "project2.h"

//Customer thread
void *Customer(void *arg) {
  //Get the value of the ith customer.
  int *pnum = (int *) arg;
  int cust = *pnum;
  free(arg);


  //determine number of bags
  customers[cust].bags = getNumber();

  //CheckIn()
  CheckIn(cust, customers[cust].bags);

  //wait for front desk employee
  wait(fdAvailable);

  //wait for customer value to be exchanged
  wait(custExchanged);

  //send customer value
  shareCust = cust;

  //send checkIn to front desk
  send(checkIn);

  //wait for customer to be given a room
  wait(giveRoom[cust]);

  //GetRoom()
  GetRoom(customers[cust].fd,cust,customers[cust].room);

  //if # of bags > 2
  if (customers[cust].bags > 2) {
    //GetBellhop()
    GetBellHop(cust);

    //wait for bellhop to help
    wait(bhAvailable);

    //wait for value of customer to be exchanged
    wait(custExchanged);

    //share customer number
    shareCust = cust;

    //send getBH to bellhop
    send(getBH);

    //wait for bellhop to get bags
    wait(gotBags[cust]);
  }

  //EnterRoom()
  EnterRoom(cust, customers[cust].room);

  if(customers[cust].bags > 2) {
    //send to bellhop that customer has entered room
    send(entersRoom[cust]);

    //wait for bellhop to give bags back
    wait(giveBags[cust]);

    //GetBackBags()
    GetBackBags(customers[cust].bh, cust);

    //send to bellhop that customer gave a tip
    send(giveTip[cust]);
  }

  //Retire for the evening
  Retire(cust);
  return NULL;
}

void *FrontDesk(void *arg) {
  int *pnum = (int *) arg;
  int frontdesk = *pnum, cust;
  free(arg);

  while (true) {
    //tell customer that Front desk is available
    send(fdAvailable);

    //wait for custoemr to checkin
    wait(checkIn);

    //get shared value
    cust = shareCust;
    customers[cust].fd = frontdesk;
    customers[cust].room = ++currRoom;

    //allow for next cust value to be exchanged
    send(custExchanged);

    //GiveRoom()
    GiveRoom(customers[cust].fd, cust, customers[cust].room);

    //giveroom to cust
    send(giveRoom[cust]);
  }

  return NULL;
}

void *Bellhop(void *arg) {
  int *pnum = (int *) arg;
  int bellhop = *pnum, cust;
  while (true) {
    //Notify customers that bellhop is available
    send(bhAvailable);

    //wait for customer to get the bellhop
    wait(getBH);

    //get customer value
    cust = shareCust;
    customers[cust].bh = bellhop;

    //notify that exchange of customer value is complete
    send(custExchanged);

    //GetBags()
    GetBags(customers[cust].bh, cust);

    //notify customer that bellhop has gotten bags
    send(gotBags[cust]);

    //wait for customer to enter room
    wait(entersRoom[cust]);

    //GiveBags()
    GiveBags(customers[cust].bh, cust);

    //tell customer bellhop can give bags
    send(giveBags[cust]);

    //get tip from the customer.
    wait(giveTip[cust]);
  }

  return NULL;
}

void joinThreads(pthread_t thread[], int numberOfThreads) {
  int status;
  //simply iterate through every thread and request for the thread to join
  for (int thread_count = 0; thread_count < numberOfThreads; ++thread_count) {
    status = pthread_join(thread[thread_count],NULL);
    if (status != 0) {
      printf("ERROR: Could not join threads\n");
      exit(1);
    }
    printf("Guest %d joined\n", thread_count);
  }
}
