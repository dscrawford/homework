# Setup

To setup for this project, simply extract all the data from the zip file, make sure 'small-10-datasets' folder is in the same directory as Homework_4.py

# Execution

Simply run python Homework_4.py with no arguments and it should work. For this project, networkx, pandas, numpy and random were used.

EX: python Homework_4.py