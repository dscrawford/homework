/* Made by Daniel Crawford on 10/18/2018
 * Email: dsc160130@utdallas.edu 
 */
#include "project2.h"

//Generates a random number between 0 and 5
int getNumber() {
  std::random_device rd;
  std::mt19937 generator(rd());
  std::uniform_int_distribution<int> distribution(0,5);
  return distribution(generator);
}
