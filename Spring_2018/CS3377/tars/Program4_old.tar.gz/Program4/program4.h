#ifndef PROGRAM4_H
#define PROGRAM4_H

#include <stdio.h>

int yylex(void);
extern char* yytext;
extern int yyparse(void);
extern int yylex(void);

#endif
