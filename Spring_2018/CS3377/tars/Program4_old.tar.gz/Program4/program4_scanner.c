#include "program4.h"
#include "parse.tab.h"

int main() {
  int token;
  while ( (token = yylex()) != 0 ) {
    char* tokenstr;
    switch(token) {
    case NAMETOKEN:
      tokenstr = "NAMETOKEN";
      break;
    case IDENTIFIERTOKEN:
      tokenstr = "IDENTIFIERTOKEN";
      break;
    case NAME_INITIAL_TOKEN:
      tokenstr = "NAME_INITIAL_TOKEN";
      break;
    case ROMANTOKEN:
      tokenstr = "ROMANTOKEN";
      break;
    case SRTOKEN:
      tokenstr = "SRTOKEN";
      break;
    case JRTOKEN:
      tokenstr = "JRTOKEN";
      break;
    case EOLTOKEN:
      tokenstr = "EOLTOKEN";
      break;
    case INTTOKEN:
      tokenstr = "INTTOKEN";
      break;
    case COMMATOKEN:
      tokenstr = "COMMATOKEN";
      break;
    case DASHTOKEN:
      tokenstr = "DASHTOKEN";
      break;
    case HASHTOKEN:
      tokenstr = "HASHTOKEN";
      break;
    default:
      tokenstr = "SYNTAX ERROR";
      break;
	}
    if (token != EOLTOKEN)
      printf("yylex returned %s token (%s)\n",tokenstr,yytext);
    else
      printf("yylex returned %s token (%d)\n",tokenstr, token);
  }
  return 0;
}
