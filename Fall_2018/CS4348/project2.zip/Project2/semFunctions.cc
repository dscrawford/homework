/* Made by Daniel Crawford on 10/18/2018
 * Email: dsc160130@utdallas.edu 
 */
#include "project2.h"

//wait for a sempaphore to be sent
void wait(sem_t &semaphore) {
  if (sem_wait(&semaphore) == -1) {
    printf("ERROR: waiting for semaphore");
    exit(1);
  }
}

//send a semaphore
void send(sem_t &semaphore) {
  if (sem_post(&semaphore) == -1) {
    printf("ERROR: sending semaphore");
    exit(1);
  }
}

//initialize semaphore with a value
void init_semaphore(sem_t& semaphore, int initialValue) {
  if (sem_init (&semaphore,0,initialValue) == -1) {
    printf("ERROR: Failed to initialize semaphore.");
    exit(1);
  }
}
