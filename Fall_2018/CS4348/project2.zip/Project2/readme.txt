COMPILATION STEPS:
1) type 'make'
2) now you have an executable "project2"

RUN STEPS:
1) to execute, type "/PATH/TO/project2"
2) if cannot execute, use "chmod u+x /PATH/TO/project2"
Details:
To find where functions are, look inside the header files project2.h and you should find which files hold them
