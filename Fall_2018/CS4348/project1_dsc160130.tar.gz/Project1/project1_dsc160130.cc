#include "project1_dsc160130.h"

int main(int argc, char** argv) {
  //Only execute if two 
  if (argc < 2) {
    std::cout << "ERROR: Need to supply arguments after executable "
	      << "(EX: ./program1_dsc160130 sample.txt sample2.txt)" << std::endl;
    exit(EXIT_FAILURE);
  }

  int mypipe[2];
  if (pipe(mypipe)) {
    std::cout << "ERROR: Failed to pipe" << std::endl;
    return 1;
  }
  
  pid_t pid = fork();
  if (pid == 0) {
    //child process
    ramProcess(argc, argv, mypipe);
  }

  else if (pid > 0) {
    //parent process
    cpuProcess(mypipe);
  }

  else {
    //fork failed
    std::cout << "fork failed" << std::endl;
    return 1;
  }
  
  return 0;
}
