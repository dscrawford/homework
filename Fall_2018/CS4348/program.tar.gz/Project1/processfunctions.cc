#include "project1_dsc160130.h"
void ramProcess(int argc, char** argv, pid_t pid, int* rampipe, int* cpupipe) {
  //Create object class ram
  RAM ram;
  //instruction count
  int instrc = 0;

  //Close unused pipes
  close(rampipe[0]);
  close(cpupipe[1]);

  //Read every file in argv and then read all of those files
  //Start at arguments after the executable
  for (int i = 1; i < argc; ++i) {
    //Inputreader gives input until
    InputReader file(argv[i]);
    while (!file.eof()) {
      std::string str;
      if ( (str = file.read()) != "NULL" ) {
	//Write to ram.
	ram.write(instrc, stoi(str));
	instrc++;
      }
    }
  }

 
  //Send instruction count to the cpu
  write(rampipe[1], &instrc, sizeof(int));
  //Send all values in memory to the cpu

  //type   = check type of behavior CPU wants(read/write/jump/end/none)
  //adr    = the address CPU wants to access
  //status = status of child process
  int type, adr, status;
  
  for (int i = 0; ; ++i) {
    //Read instruction
    int instr = ram.read(i);
    write(rampipe[1], &instr, sizeof(int));
    
    //Read type
    read(cpupipe[0], &type, sizeof(int));
    
    //0 indicates read
    if (type == 0) {
      read(cpupipe[0], &adr, sizeof(int));
      int val = ram.read(adr);
      write(rampipe[1], &val, sizeof(int));
    }
    
    //1 indicates store
    else if (type ==  1) {
      read(cpupipe[0], &adr, sizeof(int));
      //Read AC register and store
      int AC;
      read(cpupipe[0], &AC, sizeof(int));
      ram.write(adr, AC);
    }

    //2 indicates jump
    else if (type == 2) {
      std::cout << "I'm here rn!" << std::endl;
      read(cpupipe[0], &adr, sizeof(int));
      std::cout << "I'm now here!" << std::endl;
      //change which instruction to read from memory
      i = adr;
    }

    //3 indicates do nothing(not shown in code)

    //50 indicates end 
    else if (type == 50) {
      //Wait for process to end
      while (waitpid(-1, &status, WNOHANG) == 0) {
	//Wait a bit so it doesn't clog cpu
	usleep(1);
      }
      //exit code
      _exit(0);
    }
      
  }
    
}

void cpuProcess(int* rampipe, int* cpupipe) {
  //Create object class cpu
  CPU cpu(rampipe, cpupipe);
  //run the program
  cpu.runProgram();
}
