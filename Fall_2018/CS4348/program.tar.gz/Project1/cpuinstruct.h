#ifndef CPUINSTRUCT_H
#define CPUINSTRUCT_H

#include <unistd.h>
#include <memory>
#include <string>
#include <iostream>
#include <cstdlib>
#include <random>

class CPU {
private:
  //Registers
  int PC;
  int SP;
  int IR;
  int AC;
  int X;
  int Y;
  //Stack
  int* userstck;
  int* systemstck;
  //Checks whether interrupt is currently happening
  bool interruptState;

  //Pipes for communicating with RAM
  int* rampipe;
  int* cpupipe;

  //Size of stacks
  const static int SIZE = 50;

  //Add value to stack
  void addToStack(int);

  //Pop a value from stack
  int popStack();

  //Load an address from ram
  void loadRAM(int);

  //
  //CPU Instructions
  //

  //Load the value into the AC
  void loadValue(int);

  //Load the value at the address into the AC
  void loadAddr(int);

  //Load the value from the address found in the given address into the AC
  void loadIndaddr(int);
  
  //Load the value at(address+X) into the AC
  void loadIdxXaddr(int);       

  //Load the value at(address+Y) into the AC
  void loadIdxYaddr(int);

  //Load from (Sp+X) into the AC
  void loadSpX(int);

  //Store the value in the AC into the address
  void storeAddr(int);          

  //Gets a random int from 1 to 100 into the AC
  void get();

  //If port=1, writes AC as an int to the screen
  //If port=2, writes AC as a char to the screen
  void putPort(int);

  //Add the value in X to the AC
  void addX();

  //Add the value in Y to the AC
  void addY();              

  //Subtract the value in X from the AC
  void subX();

  //Subtract the value in Y from the AC
  void subY();               

  //Copy the value in the AC to X
  void copyToX();            

  //Copy the value in X to the AC
  void copyFromX();

  //Copy the value in the AC to Y
  void copyToY();

  //Copy the value in Y to the AC
  void copyFromY();          

  //Copy the value in the AC to the SP
  void copyToSP();           

  //Copy the value in SP to the AC
  void copyFromSP();         

  //Jump to the addr
  void JumpAddr(int);           

  //Jump to the address only if the value in the AC=0
  void JumpIfEqual(int);

  //Jump to the address only if the value in the AC!=0
  void JumpIfNotEqual(int);
  
  //Push return address onto stack, jump to the address
  void Call(int);               

  //Pop return address from the stack, jump to the address
  void Ret();

  //Increment the value in X
  void IncX();               

  //Decrement the value in X
  void DecX();              

  //Push AC onto stack
  void Push();              

  //Pop from stack into AC
  void Pop();

  //Perform system call
  void Int();             

  //Return from system call
  void IRet();         

  //End execution
  void End();

  //
  //End CPU Instruction
  //

public:
  CPU(int* rampipe, int* cpupipe);

  void runInstruct(int, int);//Run an instruction

  void runProgram();//Run entire program

  ~CPU();
};

#endif // CPUINSTRUCT_H
