//Made by Daniel Crawford on 3/17/2018(dsc160130)
//Section 3377.501
#include <stdio.h>
#include "program4.h"
#include "parse.tab.h"

int main() {
  printf("Operating in parse mode\n\n");
  
  //If yyparse somehow does not return 0, report it
  int returnval;
  returnval = yyparse();
  if (returnval == 0)
    printf("Parsing Successful!\n");
  else if (returnval == 1)
    printf("Parsing failure: invalid input\n");
  else if (returnval == 2)
    printf("Parsing failure: memory exhaustion\n");

  return 0;
}
