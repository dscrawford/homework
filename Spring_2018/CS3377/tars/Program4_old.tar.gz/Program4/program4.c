#include <stdio.h>
#include "program4.h"
#include "parse.tab.h"

int main() {
  printf("Operating in parse mode\n\n");
  
  int returnval;
  returnval = yyparse();
  if (returnval == 0)
    printf("Parsing Successful!\n");
  else if (returnval == 1)
    printf("Parsing failure: invalid input\n");
  else if (returnval == 2)
    printf("Parsing failure: memory exhaustion\n");
  return 0;
}
