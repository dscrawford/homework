Make sure all files in tar are in the same folder.
To execute:

make
./project1_dsc160130 {input file} {# instructions to run before interrupt}
